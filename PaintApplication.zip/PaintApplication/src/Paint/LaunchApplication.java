package Paint;

import controller.Controller;
import model.operations.MyDrawingEngine;
import model.operations.ShapeFactory;
import view.GUI;

public class LaunchApplication {
    
    public static void main(String[] args) {
        MyDrawingEngine engine = new MyDrawingEngine();
        ShapeFactory factory = new ShapeFactory(engine);
        final GUI paint = new GUI();
        Controller controller = new Controller(engine, factory, paint);
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                paint.setVisible(true);
            }
        });

    }
}
