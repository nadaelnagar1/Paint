package Paint;

public interface FactoryDP {
	
	public Shape createShape(String shape);
}
