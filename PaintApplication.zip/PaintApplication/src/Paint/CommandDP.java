package Paint;

import Paint.Shape;

public interface CommandDP {
	
	public void execute();
	public Shape getNewShape();
	public Shape getOldShape();
	public void unexecute();

}
