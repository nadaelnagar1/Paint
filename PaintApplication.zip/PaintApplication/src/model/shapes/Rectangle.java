package model.shapes;

import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.HashMap;
import java.util.Map;

import Paint.Shape;

public class Rectangle extends AbstractShape {
	public static final String LENGTH_KEY = "yAxis";
	public static final String WIDTH_KEY = "xAxis";
	
	public Rectangle() {
	
		setColor(this.getColor());
		// center of mass
		setPosition(this.getPosition());
		this.properties.put("stroke",(double) 3.0f);
		this.properties.put(LENGTH_KEY, 0.0);
		this.properties.put(WIDTH_KEY, 0.0);
		setProperties(this.properties);
		setFillColor(this.getFillColor());
	}

	@Override
	public void draw(Object canvas) {
		Graphics2D g2 = (Graphics2D) canvas;
		double stroke = this.properties.get("stroke");
		g2.setStroke(new BasicStroke((float) stroke));
		Point position = getPosition();
		double length = getProperties().get(LENGTH_KEY);
		double width = getProperties().get(WIDTH_KEY);
		g2.setColor(getColor());
		g2.drawRect(position.x, position.y, (int)width, (int)length);
		g2.setColor(getFillColor());
		g2.fillRect(position.x, position.y, (int)width, (int)length);
	}
        
	@Override
	public Object clone() throws CloneNotSupportedException{
            AbstractShape clonedShape = new Rectangle();
            return cloneShape(clonedShape);
        }

}
