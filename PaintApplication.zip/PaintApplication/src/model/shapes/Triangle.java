package model.shapes;

import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.HashMap;
import java.util.Map;

import Paint.Shape;

public class Triangle extends AbstractShape{
	public static final String X1_KEY = "x1";
	public static final String Y1_KEY = "y1";
	public static final String X2_KEY = "x2";
	public static final String Y2_KEY = "y2";
	public static final String X3_KEY = "x3";
	public static final String Y3_KEY = "y3";
	
	public Triangle() {
		properties.put(X1_KEY, 0.0);
		properties.put(Y1_KEY, 0.0);
		properties.put(X2_KEY, 0.0);
		properties.put(Y2_KEY, 0.0);
		properties.put(X3_KEY, 0.0);
		properties.put(Y3_KEY, 0.0);
		properties.put("stroke",(double) 3.0f);
	}

	@Override
	public void draw(Object canvas) {
		Graphics2D g2 = (Graphics2D) canvas;
		g2.setStroke(new BasicStroke((float)(double) properties.get("stroke")));
		int[] x = new int[3];
		int[] y = new int[3];
		x[0] = properties.get(X1_KEY).intValue();
		y[0] = properties.get(Y1_KEY).intValue();
		x[1] = properties.get(X2_KEY).intValue();
		y[1] = properties.get(Y2_KEY).intValue();
		x[2] = properties.get(X3_KEY).intValue();
		y[2] = properties.get(Y3_KEY).intValue();
		g2.setColor(getColor());
		g2.drawPolygon(x, y, 3);
		g2.setColor(getFillColor());
		g2.fillPolygon(x, y, 3);
	}
        
	@Override
	public Object clone() throws CloneNotSupportedException{
            AbstractShape clonedShape = new Triangle();
            return cloneShape(clonedShape);
        }  

}
