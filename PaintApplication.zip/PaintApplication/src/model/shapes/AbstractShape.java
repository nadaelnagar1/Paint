package model.shapes;

import java.awt.Color;
import java.awt.Point;
import java.util.HashMap;
import java.util.Map;

import Paint.Shape;

public abstract class AbstractShape implements Shape, Cloneable{

    protected Map<String, Double> properties;
    protected Point position;
    protected Color color;
    protected Color fillColor;

    public AbstractShape() {
        properties = new HashMap<>();
        position = new Point(13, 12);
        this.color = color.black;
        this.fillColor = color.white;
    }

    @Override
    public void setPosition(Point position) {
        this.position = position;
    }

    @Override
    public Point getPosition() {
        return this.position;
    }

    @Override
    public void setColor(Color color) {
        this.color = color;
    }

    @Override
    public Color getColor() {
        return this.color;
    }

    @Override
    public Map<String, Double> getProperties() {
        return this.properties;
    }

    @Override
    public void setProperties(Map<String, Double> properties) {
        this.properties = properties;
    }

    @Override
    public void setFillColor(Color color) {
        this.fillColor = color;
    }

    @Override
    public Color getFillColor() {
        return this.fillColor;
    }

    @Override
    public Object clone() throws CloneNotSupportedException{
        return null;
    }

    protected Object cloneShape(Shape clonedShape) {
        clonedShape.setColor(color);
        clonedShape.setFillColor(fillColor);
        clonedShape.setPosition(position);
        Map<String, Double> newprop = new HashMap<>();
        newprop.putAll(properties);
        clonedShape.setProperties(newprop);
        return clonedShape;
    }
     
}
