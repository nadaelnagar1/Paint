package model.shapes;

import java.util.HashMap;
import java.util.Map;

import Paint.Shape;

public class Square extends Rectangle{
	
	public Square(){
		super();
	}
        
        @Override
	public Object clone() throws CloneNotSupportedException{
            AbstractShape clonedShape = new Square();
            return cloneShape(clonedShape);
        }
        
}
