package model.shapes;

import java.util.HashMap;
import java.util.Map;

import Paint.Shape;

public class Circle extends Ellipse{
	
        public Circle(){
		 super();
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException{
            AbstractShape clonedShape = new Circle();
            return cloneShape(clonedShape);
        }  
}
