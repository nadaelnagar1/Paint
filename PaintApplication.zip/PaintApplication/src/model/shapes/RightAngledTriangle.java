
package model.shapes;

public class RightAngledTriangle extends Triangle {

    public RightAngledTriangle() {
        super();
    }
    
    @Override
    public Object clone() throws CloneNotSupportedException{
            AbstractShape clonedShape = new RightAngledTriangle();
            return cloneShape(clonedShape);
        }  
    
}
