package model.shapes;

import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.HashMap;
import java.util.Map;

import Paint.Shape;

public class LineSegment extends AbstractShape {
	
	public static final String X1_KEY = "x1";
	public static final String Y1_KEY = "y1";
	public static final String X2_KEY = "x2";
	public static final String Y2_KEY = "y2";
	
	public LineSegment() {
		properties.put(X1_KEY, 0.0);
		properties.put(Y1_KEY, 0.0);
		properties.put(X2_KEY, 0.0);
                properties.put(Y2_KEY, 0.0);
		properties.put("stroke",(double) 3.0f);
	}

	@Override
	public void draw(Object canvas) {
		Graphics2D g2 = (Graphics2D) canvas;
		double stroke = properties.get("stroke");
		setPosition(new Point(properties.get(X1_KEY).intValue(), properties.get(Y1_KEY).intValue()));
		g2.setStroke(new BasicStroke((float) stroke));
		g2.setColor(getColor());
		g2.drawLine( position.x, position.y, properties.get(X2_KEY).intValue(), properties.get(Y2_KEY).intValue());
	}

	@Override
	public Object clone() throws CloneNotSupportedException{
            AbstractShape clonedShape = new LineSegment();
            return cloneShape(clonedShape);
        }
        
}
