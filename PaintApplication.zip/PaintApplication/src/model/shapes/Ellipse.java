package model.shapes;

import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.HashMap;
import java.util.Map;

import Paint.Shape;

public class Ellipse extends AbstractShape{
    
	public static final String X_KEY = "xAxis";
	public static final String Y_KEY = "yAxis";

	public Ellipse() {
            this.properties.put("stroke",(double) 3.0f);
            this.properties.put(X_KEY, 0.0);
            this.properties.put(Y_KEY, 0.0);
	}

	@Override
	public void draw(Object canvas) {
            Graphics2D g2 = (Graphics2D) canvas;
            double stroke = properties.get("stroke");
            g2.setStroke(new BasicStroke((float) stroke));
            g2.setColor(getColor());
            g2.drawOval(position.x, position.y, (int)(double)properties.get(X_KEY), (int)(double)properties.get(Y_KEY));
            g2.setColor(getFillColor());
            g2.fillOval(position.x, position.y, (int)(double)properties.get(X_KEY), (int)(double)properties.get(Y_KEY));
	}
        
	@Override
	public Object clone() throws CloneNotSupportedException{
            AbstractShape clonedShape = new Ellipse();
            return cloneShape(clonedShape);
        }        
}
