package model.operations;

import java.util.ArrayList;

import Paint.Shape;
import Paint.CommandDP;

public class AddShape implements CommandDP{
	
	private ArrayList<Shape> shapes;
	private Shape shape;
	
        public AddShape(ArrayList<Shape> shapes, Shape shape){
            this.shapes = shapes;
            this.shape = shape;
	}
	@Override
	public void execute() {
            this.shapes.add(shape);
	}

	@Override
	public void unexecute() {
            this.shapes.remove(shape);
	}
        
	@Override
	public Shape getNewShape() {
            return shape;
	}
        
	@Override
	public Shape getOldShape() {
            return null;
	}
	
}
