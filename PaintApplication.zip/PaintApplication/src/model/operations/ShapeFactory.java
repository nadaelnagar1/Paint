package model.operations;

import Paint.DrawingEngine;
import Paint.Shape;
import Paint.FactoryDP;

public class ShapeFactory implements FactoryDP {

    private Shape shape = null;
    private final DrawingEngine engine;

    public ShapeFactory(DrawingEngine engine) {
        this.engine = engine;
    }

    @Override
    public Shape createShape(String shape) {

        for (Class<? extends Shape> i : engine.getSupportedShapes()) {
            if (shape.equals(i.getSimpleName())) {
                try {
                    this.shape = (Shape) i.newInstance();
                    return this.shape;

                } catch (InstantiationException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    public Shape createShape(Shape shape) {
        String shapeName = shape.getClass().getSimpleName();
        return createShape(shapeName);
    }
}
