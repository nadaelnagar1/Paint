# Paint-Project

A Vector Based Drawing Application. It allows the user to draw different shapes and manipulate them. It has a user-friendly interface and supports many features such as save, load, copy, paste, undo, redo, move, resize , delete shapes and add plugins.

[See User Guide](https://docs.google.com/document/d/1aBmjGyNOZRfxBOj0UPWo5OMOv6sGYp1cqiZPauOR0iw/)

All Credits goes to Mostafa Labib, Mahmoud Tarek.
